const express = require('express');
const { check, validationResult } = require('express-validator');
const Genero = require('../models/Genero');

const router = express.Router();


router.get('/', async (req, res) => {
    try {
        const generos = await Genero.find();
        res.json(generos);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});


router.post(
    '/',
    [
        check('nombre', 'El nombre es obligatorio').not().isEmpty(),
        check('descripcion', 'La descripción es obligatoria').not().isEmpty()
    ],
    async (req, res) => {
        const errores = validationResult(req);
        if (!errores.isEmpty()) {
            return res.status(400).json({ errores: errores.array() });
        }

        try {
            const nuevoGenero = new Genero(req.body);
            await nuevoGenero.save();
            res.status(201).json(nuevoGenero);
        } catch (error) {
            res.status(500).json({ mensaje: 'Error en el servidor' });
        }
    }
);


router.put('/:id', async (req, res) => {
    try {
        const genero = await Genero.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!genero) {
            return res.status(404).json({ mensaje: 'Género no encontrado' });
        }
        res.json(genero);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});


router.delete('/:id', async (req, res) => {
    try {
        const genero = await Genero.findByIdAndDelete(req.params.id);
        if (!genero) {
            return res.status(404).json({ mensaje: 'Género no encontrado' });
        }
        res.json({ mensaje: 'Género eliminado' });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

module.exports = router;

