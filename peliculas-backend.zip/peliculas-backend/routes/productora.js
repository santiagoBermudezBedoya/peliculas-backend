const express = require('express');
const { check, validationResult } = require('express-validator');
const Productora = require('../models/Productora');

const router = express.Router();

// Obtener todas las productoras (GET)
router.get('/', async (req, res) => {
    try {
        const productoras = await Productora.find();
        res.json(productoras);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

// Crear una productora (POST)
router.post(
    '/',
    [
        check('nombre', 'El nombre de la productora es obligatorio').not().isEmpty(),
        check('slogan', 'El slogan es obligatorio').not().isEmpty(),
        check('descripcion', 'La descripción es obligatoria').not().isEmpty()
    ],
    async (req, res) => {
        const errores = validationResult(req);
        if (!errores.isEmpty()) {
            return res.status(400).json({ errores: errores.array() });
        }

        try {
            const nuevaProductora = new Productora(req.body);
            await nuevaProductora.save();
            res.status(201).json(nuevaProductora);
        } catch (error) {
            res.status(500).json({ mensaje: 'Error en el servidor' });
        }
    }
);

// Actualizar una productora (PUT)
router.put('/:id', async (req, res) => {
    try {
        const productora = await Productora.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!productora) {
            return res.status(404).json({ mensaje: 'Productora no encontrada' });
        }
        res.json(productora);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

// Eliminar una productora (DELETE)
router.delete('/:id', async (req, res) => {
    try {
        const productora = await Productora.findByIdAndDelete(req.params.id);
        if (!productora) {
            return res.status(404).json({ mensaje: 'Productora no encontrada' });
        }
        res.json({ mensaje: 'Productora eliminada' });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

module.exports = router;
