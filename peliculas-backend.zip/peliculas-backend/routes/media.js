const express = require('express');
const { check, validationResult } = require('express-validator');
const Media = require('../models/Media');

const router = express.Router();

// Obtener todas las películas y series (GET)
router.get('/', async (req, res) => {
    try {
        const media = await Media.find().populate('genero director productora tipo');
        res.json(media);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

// Crear una película o serie (POST)
router.post(
    '/',
    [
        check('serial', 'El serial es obligatorio').not().isEmpty(),
        check('titulo', 'El título es obligatorio').not().isEmpty(),
        check('url', 'La URL de la película es obligatoria').not().isEmpty(),
        check('anioEstreno', 'El año de estreno es obligatorio').isNumeric(),
        check('genero', 'El género es obligatorio').not().isEmpty(),
        check('director', 'El director es obligatorio').not().isEmpty(),
        check('productora', 'La productora es obligatoria').not().isEmpty(),
        check('tipo', 'El tipo es obligatorio').not().isEmpty()
    ],
    async (req, res) => {
        const errores = validationResult(req);
        if (!errores.isEmpty()) {
            return res.status(400).json({ errores: errores.array() });
        }

        try {
            const nuevaMedia = new Media(req.body);
            await nuevaMedia.save();
            res.status(201).json(nuevaMedia);
        } catch (error) {
            res.status(500).json({ mensaje: 'Error en el servidor' });
        }
    }
);

// Actualizar una película o serie (PUT)
router.put('/:id', async (req, res) => {
    try {
        const media = await Media.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!media) {
            return res.status(404).json({ mensaje: 'Película o serie no encontrada' });
        }
        res.json(media);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

// Eliminar una película o serie (DELETE)
router.delete('/:id', async (req, res) => {
    try {
        const media = await Media.findByIdAndDelete(req.params.id);
        if (!media) {
            return res.status(404).json({ mensaje: 'Película o serie no encontrada' });
        }
        res.json({ mensaje: 'Película o serie eliminada' });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

module.exports = router;
