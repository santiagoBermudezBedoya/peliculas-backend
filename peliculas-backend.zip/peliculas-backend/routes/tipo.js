const express = require('express');
const { check, validationResult } = require('express-validator');
const Tipo = require('../models/Tipo');

const router = express.Router();

// Obtener todos los tipos (GET)
router.get('/', async (req, res) => {
    try {
        const tipos = await Tipo.find();
        res.json(tipos);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

// Crear un tipo (POST)
router.post(
    '/',
    [
        check('nombre', 'El nombre del tipo es obligatorio').not().isEmpty(),
        check('descripcion', 'La descripción es obligatoria').not().isEmpty()
    ],
    async (req, res) => {
        const errores = validationResult(req);
        if (!errores.isEmpty()) {
            return res.status(400).json({ errores: errores.array() });
        }

        try {
            const nuevoTipo = new Tipo(req.body);
            await nuevoTipo.save();
            res.status(201).json(nuevoTipo);
        } catch (error) {
            res.status(500).json({ mensaje: 'Error en el servidor' });
        }
    }
);

// Actualizar un tipo (PUT)
router.put('/:id', async (req, res) => {
    try {
        const tipo = await Tipo.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!tipo) {
            return res.status(404).json({ mensaje: 'Tipo no encontrado' });
        }
        res.json(tipo);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

// Eliminar un tipo (DELETE)
router.delete('/:id', async (req, res) => {
    try {
        const tipo = await Tipo.findByIdAndDelete(req.params.id);
        if (!tipo) {
            return res.status(404).json({ mensaje: 'Tipo no encontrado' });
        }
        res.json({ mensaje: 'Tipo eliminado' });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error en el servidor' });
    }
});

module.exports = router;
