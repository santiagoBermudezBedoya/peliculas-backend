const mongoose = require('mongoose');

const GeneroSchema = new mongoose.Schema({
    nombre: { type: String, required: true, unique: true },
    estado: { type: Boolean, default: true },
    fechaCreacion: { type: Date, default: Date.now },
    fechaActualizacion: { type: Date, default: Date.now },
    descripcion: { type: String }
});

module.exports = mongoose.model('Genero', GeneroSchema);

