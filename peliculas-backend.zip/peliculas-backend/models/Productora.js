const mongoose = require('mongoose');

const ProductoraSchema = new mongoose.Schema({
    nombre: { type: String, required: true },
    estado: { type: Boolean, default: true },
    fechaCreacion: { type: Date, default: Date.now },
    fechaActualizacion: { type: Date, default: Date.now },
    slogan: { type: String },
    descripcion: { type: String }
});

module.exports = mongoose.model('Productora', ProductoraSchema);
